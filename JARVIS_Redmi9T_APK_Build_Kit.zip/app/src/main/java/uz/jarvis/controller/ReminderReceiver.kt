package uz.jarvis.controller

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Reserved for scheduled notification support in the next iteration.
    }
}
