# JARVIS Android Controller — boshlang‘ich loyiha

Bu Android native manba-kod loyihasi (APK emas). Uni Android Studio’da ochib build qilish kerak.

## Hozirgi prototip
- Ovozli buyruq tanish (Android speech recognizer mavjud bo‘lsa).
- Matnni ovoz chiqarib aytish (TTS).
- Wi-Fi/Internet tezkor sozlamalar panelini ochish. Android 10+ oddiy ilovalarga Wi-Fi’ni yashirincha to‘g‘ridan-to‘g‘ri yoqish/o‘chirishga ruxsat bermaydi; foydalanuvchi panelda o‘zi bosadi.
- Google qidiruvini ochish.
- Gmail/pochta ilovasida xat yozish oynasini ochishga urinish.
- Telegram va YouTube’ni ochish.
- Budilnik ilovasiga eslatma vaqtini taklif qilish.
- Accessibility Service uchun ruxsatli boshlang‘ich skelet.

## Muhim cheklovlar
- Bu hali umumiy maqsadli LLM bilan ulangan, hamma topshiriqni bajara oladigan JARVIS emas.
- Doimiy “Hey JARVIS” tinglashi va ekran o‘chiq paytda ishlashi hali yo‘q. Android mikrofon/fon ishlashini cheklaydi; buning uchun foreground service, ko‘rinadigan bildirishnoma, batareya sozlamalari va qo‘shimcha sinov kerak.
- Accessibility ruxsati juda kuchli. Faqat o‘zingiz ishonadigan ilovaga bering. Ushbu skelet ekran matnlarini serverga yubormaydi.
- Twilio telefon tarmog‘i qo‘ng‘irog‘i uchun alohida server va Twilio hisobini talab qiladi; bu Android prototipiga hali ulanmagan.

## Android Studio
1. Android Studio’da `Open` ni tanlab shu papkani oching.
2. Gradle sync tugashini kuting.
3. Telefonni USB debugging bilan ulang yoki emulator tanlang.
4. Run bosing.
5. Mikrofon ruxsatini bering. “Telefon boshqaruviga ruxsat” tugmasi Accessibility sozlamalarini ochadi.

Termux’ning o‘zida APK yig‘ish qiyin bo‘lishi mumkin. Bu ZIP manba-kod, tayyor APK emas.
