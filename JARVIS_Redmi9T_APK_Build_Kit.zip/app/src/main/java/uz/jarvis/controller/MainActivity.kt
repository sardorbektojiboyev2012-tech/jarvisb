package uz.jarvis.controller

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private val reqSpeech = 100
    private val reqCall = 101
    private var pendingCall = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 202)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(28, 36, 28, 28); gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFF0B1020.toInt())
        }
        val title = TextView(this).apply { text = "JARVIS AI"; textSize = 30f; setTextColor(0xFFFFFFFF.toInt()) }
        val desc = TextView(this).apply { text = "Telefon buyruqlari • Ovoz • Eslatmalar"; textSize = 15f; setTextColor(0xFFB9C7E5.toInt()); setPadding(0,8,0,22) }
        val listen = Button(this).apply { text = "🎙 GAPIRISH"; setOnClickListener { listen() } }
        val wifi = Button(this).apply { text = "Wi-Fi sozlamalari"; setOnClickListener { openInternetPanel() } }
        val access = Button(this).apply { text = "Telefon boshqaruviga ruxsat"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        val reminder = Button(this).apply { text = "Eslatma qo‘yish"; setOnClickListener { setReminder() } }
        status = TextView(this).apply { text = "Mikrofon tugmasini bosib buyruq bering."; textSize = 16f; setTextColor(0xFFFFFFFF.toInt()); setPadding(0,18,0,18) }
        listOf(title,desc,listen,wifi,access,reminder,status).forEach { layout.addView(it, LinearLayout.LayoutParams(-1, if (it == title || it == desc || it == status) -2 else -2).apply { bottomMargin=10 }) }
        setContentView(ScrollView(this).apply { addView(layout) })
    }
    override fun onInit(statusCode: Int) { if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale("uz","UZ") }
    private fun say(s: String) { status.text = s; if (::tts.isInitialized) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis") }
    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVISga buyruq bering")
        }
        try { startActivityForResult(i, reqSpeech) } catch (_: Exception) { say("Ovoz tanish xizmati bu telefonda mavjud emas.") }
    }
    @Deprecated("Legacy activity result for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqSpeech && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            handleCommand(spoken.lowercase(Locale("uz","UZ")))
        }
    }
    private fun handleCommand(c: String) {
        when {
            c.contains("wi-fi") || c.contains("wifi") || c.contains("internet") -> openInternetPanel()
            c.contains("google") || c.contains("qidir") -> {
                val query = c.replace("google", "").replace("qidir", "").replace("dan", "").trim()
                startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", query.ifBlank { "Google" }))
                say("Qidiruvni ochdim.")
            }
            c.contains("gmail") || c.contains("email") || c.contains("pochta") -> {
                val body = c.substringAfter("yoz", "").trim()
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).apply {
                    putExtra(Intent.EXTRA_SUBJECT, "JARVIS orqali")
                    putExtra(Intent.EXTRA_TEXT, body)
                }
                try { startActivity(i); say("Pochta ilovasini ochdim. Yuborishdan oldin tekshiring.") }
                catch (_: Exception) { say("Pochta ilovasi topilmadi.") }
            }
            c.contains("telegram") -> openApp("org.telegram.messenger")
            c.contains("youtube") -> openApp("com.google.android.youtube")
            c.contains("soat") || c.contains("eslat") || c.contains("budilnik") -> setReminder()
            c.contains("qo‘ng‘iroq") || c.contains("qongiroq") || c.contains("telefon qil") -> {
                val number = Regex("""[+0-9][0-9 ()-]{5,}""").find(c)?.value?.replace(Regex("""[ ()-]"""), "")
                if (number != null) {
                    try {
                        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
                        say("Telefon raqamini terish oynasini ochdim. Qo‘ng‘iroq qilishdan oldin raqamni tekshiring.")
                    } catch (_: Exception) { say("Telefon ilovasini ochib bo‘lmadi.") }
                } else {
                    try {
                        startActivity(Intent(Intent.ACTION_DIAL))
                        say("Telefon terish oynasini ochdim. Kontakt yoki raqamni o‘zingiz tanlang.")
                    } catch (_: Exception) { say("Telefon ilovasini ochib bo‘lmadi.") }
                }
            }
            else -> say("Buyruqni to‘liq tushunmadim. Wi-Fi, Google, Gmail, Telegram yoki eslatma deb ayting.")
        }
    }
    private fun openInternetPanel() {
        try {
            if (Build.VERSION.SDK_INT >= 29) startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            else startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            say("Internet sozlamalarini ochdim. Wi-Fi tugmasini bosing.")
        } catch (_: Exception) { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
    }
    private fun openApp(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) { startActivity(i); say("Ilovani ochdim.") } else say("Bu ilova o‘rnatilmagan.")
    }
    private fun setReminder() {
        val cal = Calendar.getInstance().apply { add(Calendar.MINUTE, 1) }
        val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, cal.get(Calendar.HOUR_OF_DAY))
            putExtra(AlarmClock.EXTRA_MINUTES, cal.get(Calendar.MINUTE))
            putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS eslatmasi")
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        }
        try { startActivity(i); say("Budilnik sozlamasini ochdim. Vaqtni tekshirib saqlang.") }
        catch (_: Exception) { say("Soat ilovasini ochib bo‘lmadi.") }
    }
    override fun onDestroy() { if (::tts.isInitialized) { tts.stop(); tts.shutdown() }; super.onDestroy() }
}
