package uz.jarvis.controller

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Accessibility service skeleton. User must explicitly enable it in Android Settings.
 * It does not secretly read or control apps; command-specific actions should be added
 * with clear user consent and tested against the target app UI.
 */
class JarvisAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally no screen contents are collected or transmitted.
    }
    override fun onInterrupt() {}
    fun clickVisibleText(label: String): Boolean {
        val root: AccessibilityNodeInfo = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(label)
        for (node in nodes) {
            var current: AccessibilityNodeInfo? = node
            while (current != null) {
                if (current.isClickable) return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                current = current.parent
            }
        }
        return false
    }
}
